use tributos
let filter = {"conductores.numeroDocumento": 7694465}
let doc = db.vehiculos.findOne(filter);
doc.placa;
doc.conductores;
doc.conductores.push({nombre: "Miguel Dias", numeroDocumento: "5694389"})
let nro = doc.conductores[3].numeroDocumento.valueOf()
nro
doc.conductores[3].numeroDocumento = NumberInt(nro);
db.vehiculos.replaceOne(filter, doc);