show dbs
use aduana
show collections
db.vehiculos.insert({placa: "ABC-123", conductor : {nombre: "Julio Rios", numeroDocumento: NumberInt(10235464)}})
db.vehiculos.insert({placa: "ABC-456", conductor : {nombre: "Jose Chavez", numeroDocumento: NumberInt(60535262)}})
db.vehiculos.insert({placa: "DEF-456", conductor : {nombre: "Jorge Ramos", numeroDocumento: NumberInt(80537261)}})
db.vehiculos.find()
db.vehiculos.update({placa: "ABC-123"}, {$set: {conductor: {nombre: "Mario Perez", numeroDocumento: NumberInt(8694464)}}})
db.vehiculos.find()
db.vehiculos.update({placa: "ABC-123"}, {$set: {"conductor.nombre": "Aldo Gutierrez"}}, {multi: true})
db.vehiculos.find()
db.vehiculos.update({placa: "ABC-123"}, {$set: {"conductor.tipoDocumento": "01"}}, {multi: true})
db.vehiculos.find({placa: { $in: [/^ABC/]}})
db.vehiculos.find(null, {placa: 1, conductor: 1, "conductor.nombre": 1, _id: 0}).limit(2)