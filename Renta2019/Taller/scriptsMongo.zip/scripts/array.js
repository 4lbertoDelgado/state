// use tributos
// db.vehiculos.insert({placa: "ABC-123", conductores: [{nombre: "Julio Rios", numeroDocumento: NumberInt(10235464)}]})
// db.vehiculos.find()
// db.vehiculos.update({placa: "ABC-123"}, {$push: {conductores: {nombre: "Mario Perez", tipoDocumento: "01", numeroDocumento: NumberInt(8694464)}}})
// db.vehiculos.find()
// db.vehiculos.update({placa: "ABC-123"}, {$push: {conductores: {nombre: "Aldo Gutierrez", numeroDocumento: NumberInt(7694465)}}})
// db.vehiculos.find()
// db.vehiculos.update({"conductores.numeroDocumento": 7694465}, {$set: {"conductores.$.nombre": "Aldo Miyashiro"}})
db.vehiculos.find()